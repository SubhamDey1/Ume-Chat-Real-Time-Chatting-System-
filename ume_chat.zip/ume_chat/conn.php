<?php
    function connected() {
        return  mysqli_connect("localhost","root","","chat_app");
    }
?>